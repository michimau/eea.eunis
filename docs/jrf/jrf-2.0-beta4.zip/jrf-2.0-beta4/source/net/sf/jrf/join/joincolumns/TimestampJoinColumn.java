/*
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 *
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations under
 * the License.
 *
 * The Original Code is jRelationalFramework.
 *
 * The Initial Developer of the Original Code is is.com.
 * Portions created by is.com are Copyright (C) 2000 is.com.
 * All Rights Reserved.
 *
 * Contributor: Jonathan Carlson (joncrlsn@users.sf.net)
 * Contributor: ____________________________________
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License (the "GPL") or the GNU Lesser General
 * Public license (the "LGPL"), in which case the provisions of the GPL or
 * LGPL are applicable instead of those above.  If you wish to allow use of
 * your version of this file only under the terms of either the GPL or LGPL
 * and not to allow others to use your version of this file under the MPL,
 * indicate your decision by deleting the provisions above and replace them
 * with the notice and other provisions required by either the GPL or LGPL
 * License.  If you do not delete the provisions above, a recipient may use
 * your version of this file under either the MPL or GPL or LGPL License.
 *
 */
package net.sf.jrf.join.joincolumns;

import java.sql.SQLException;
import java.sql.Timestamp;
import net.sf.jrf.column.GetterSetter;
import net.sf.jrf.join.*;


import net.sf.jrf.sql.JRFResultSet;

/**
 *  This subclass of JoinColumn represents a Timestamp column we want joined
 *  from another table.
 */
public class TimestampJoinColumn
     extends JoinColumn
{

    /* ===============  Static Variables  =============== */
    protected final static Class s_class = Timestamp.class;


    /* ===============  Constructors  =============== */

    /**
     * Construct an instance that is ready to be used.
     *
     * @param columnName  a value of type 'Timestamp' - can include the alias
     *                   like this: "Name PersonName"
     * @param setterName  a value of type 'Timestamp'
     */
    public TimestampJoinColumn(
        String columnName,
        String setterName)
    {
        super(columnName,
            setterName);
    }


    /**
     * Construct an instance that is ready to be used.
     *
     * @param columnName   a value of type 'String'
     * @param columnAlias  a value of type 'String'
     * @param setterName   a value of type 'String'
     */
    public TimestampJoinColumn(
        String columnName,
        String columnAlias,
        String setterName)
    {
        super(columnName,
            columnAlias,
            setterName);
    }

    /**
     * Constructs instance using column name and getter setter impl.
     *
     * @param columnName        name of the column.
     * @param getterSetterImpl  implementation of <code>GetterSetter</code> for the column.
     */
    public TimestampJoinColumn(String columnName, GetterSetter getterSetterImpl)
    {
        super(columnName, getterSetterImpl);
    }

    /**
     * Gets the columnValueFrom attribute of the TimestampJoinColumn object
     *
     * @param jrfResultSet      Description of the Parameter
     * @return                  The columnValueFrom value
     * @exception SQLException  Description of the Exception
     */
    public Object getColumnValueFrom(JRFResultSet jrfResultSet)
        throws SQLException
    {
        return jrfResultSet.getTimestamp(i_columnIdx);
    }


    /**
     * Gets the columnClass attribute of the TimestampJoinColumn object
     *
     * @return   The columnClass value
     */
    public Class getColumnClass()
    {
        return s_class;
    }

}// TimestampJoinColumn
